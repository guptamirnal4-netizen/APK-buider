#!/bin/bash
set -e

echo "🔨 Step 1/4: Installing dependencies..."
npm install

echo "🏗️  Step 2/4: Building web app..."
npm run build

echo "📦 Step 3/4: Syncing to Android..."
npx cap sync android

echo "🚀 Step 4/4: Opening Android Studio..."
npx cap open android

echo "✅ Done! In Android Studio: Build → Build APK(s)"
echo "   APK path: android/app/build/outputs/apk/debug/app-debug.apk"
