import { useNavigate, useLocation } from "react-router-dom";

// --- SVG Icons ---

function HomeIcon({ active }: { active: boolean }) {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={active ? "#0F766E" : "#6B7280"} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
      <polyline points="9 22 9 12 15 12 15 22" />
    </svg>
  );
}

function HarvestIcon({ active }: { active: boolean }) {
  const c = active ? "#0F766E" : "#6B7280";
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="12" y1="1" x2="12" y2="23" />
      <path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6" />
    </svg>
  );
}

function WrappedIcon({ active }: { active: boolean }) {
  const c = active ? "#0F766E" : "#6B7280";
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
    </svg>
  );
}

function ProfileIcon({ active }: { active: boolean }) {
  const c = active ? "#0F766E" : "#6B7280";
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" />
      <circle cx="12" cy="7" r="4" />
    </svg>
  );
}

function BackArrow() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="15 18 9 12 15 6" />
    </svg>
  );
}

// --- Progress Bar ---
export function ProgressBar({ pct }: { pct: number }) {
  return (
    <div className="w-full h-[3px] bg-accent-soft">
      <div
        className="h-full bg-accent transition-all duration-500"
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}

// --- Header ---
interface HeaderProps {
  title: string;
  subtitle?: string;
  showBack?: boolean;
  rightElement?: React.ReactNode;
  progress?: number; // 0–100
}

export function Header({ title, subtitle, showBack = false, rightElement, progress }: HeaderProps) {
  const navigate = useNavigate();
  return (
    <div className="sticky top-0 z-50 bg-accent text-white">
      <div className="flex items-center gap-3 px-4 py-3">
        {showBack && (
          <button onClick={() => navigate(-1)} className="flex-shrink-0 p-1 -ml-1 rounded-full hover:bg-white/10 transition">
            <BackArrow />
          </button>
        )}
        <div className="flex-1 min-w-0">
          <h1 className="font-bold text-base leading-tight truncate">{title}</h1>
          {subtitle && (
            <p className="text-[11px] text-accent-soft/80 tracking-widest uppercase mt-0.5">{subtitle}</p>
          )}
        </div>
        {rightElement && <div className="flex-shrink-0">{rightElement}</div>}
      </div>
      {progress !== undefined && (
        <ProgressBar pct={progress} />
      )}
    </div>
  );
}

// --- Bottom Nav ---
const navItems = [
  { label: "Home", path: "/dashboard", key: "home", Icon: HomeIcon },
  { label: "Harvest", path: "/harvest", key: "harvest", Icon: HarvestIcon },
  { label: "Wrapped", path: "/wrapped", key: "wrapped", Icon: WrappedIcon },
  { label: "Profile", path: "/profile", key: "profile", Icon: ProfileIcon },
];

export function BottomNav() {
  const navigate = useNavigate();
  const location = useLocation();

  const activeKey = (() => {
    if (location.pathname === "/dashboard") return "home";
    if (location.pathname === "/harvest") return "harvest";
    if (location.pathname === "/wrapped") return "wrapped";
    if (location.pathname === "/profile") return "profile";
    return "";
  })();

  return (
    <div className="sticky bottom-0 z-50 bg-white border-t border-gray-200 flex">
      {navItems.map(({ label, path, key, Icon }) => {
        const active = activeKey === key;
        return (
          <button
            key={key}
            onClick={() => navigate(path)}
            className={`flex-1 flex flex-col items-center py-2 gap-0.5 transition ${active ? "text-accent" : "text-muted"}`}
          >
            <Icon active={active} />
            <span className="text-[10px] font-medium tracking-wide">{label}</span>
          </button>
        );
      })}
    </div>
  );
}
