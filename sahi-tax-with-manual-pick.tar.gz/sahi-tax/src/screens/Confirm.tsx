import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Header } from "../components/Layout";
import { inr } from "../lib/format";

type ConfirmState = "review" | "executing" | "done";

const trades = [
  { label: "Sell Vodafone Idea", detail: "2,000 shares @ ₹16" },
  { label: "Buy Bharti Airtel", detail: "25 shares @ ₹1,280" },
  { label: "Sell One97 Communications", detail: "25 shares @ ₹840" },
  { label: "Buy FSN E-Commerce (Nykaa)", detail: "30 shares @ ₹175" },
  { label: "Sell Punjab National Bank", detail: "500 shares @ ₹76" },
  { label: "Buy State Bank of India", detail: "25 shares @ ₹740" },
];

export default function Confirm() {
  const navigate = useNavigate();
  const [state, setState] = useState<ConfirmState>("review");
  const [tradeProgress, setTradeProgress] = useState(0); // 0..6

  function execute() {
    setState("executing");
    let idx = 0;
    const tick = () => {
      idx++;
      setTradeProgress(idx);
      if (idx < trades.length) {
        setTimeout(tick, 500);
      } else {
        setTimeout(() => setState("done"), 600);
      }
    };
    setTimeout(tick, 300);
  }

  return (
    <div className="min-h-screen bg-bgsoft flex flex-col">
      <Header
        title="Confirm & Execute"
        subtitle="Step 4 of 4"
        showBack={state === "review"}
        progress={100}
      />

      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {state === "review" && <ReviewState onExecute={execute} />}
        {state === "executing" && <ExecutingState progress={tradeProgress} />}
        {state === "done" && <DoneState navigate={navigate} />}
      </div>
    </div>
  );
}

function ReviewState({ onExecute }: { onExecute: () => void }) {
  return (
    <>
      {/* Summary card */}
      <div className="bg-white border-2 border-ink rounded-2xl p-4">
        <p className="font-bold text-body mb-3">Tax Saving Opportunity</p>
        <ol className="space-y-2 list-decimal list-inside text-sm text-body">
          <li>Sell 2,000 shares of Vodafone Idea (Loss: {inr(24000)}) to offset gains from HDFC (Gain: {inr(12000)})</li>
          <li>Sell 25 shares of Paytm (Loss: {inr(13000)}) to offset gains from Reliance (Gain: {inr(25000)})</li>
          <li>Sell 500 shares of PNB (Loss: {inr(12000)}) to offset gains from HDFC (Gain: {inr(12000)})</li>
        </ol>
        <div className="mt-4 bg-accent-soft rounded-xl p-3">
          <p className="text-accent font-bold text-sm">
            ₹3,500 saved in tax + ₹8,000 banked for future
          </p>
        </div>
      </div>

      {/* After execution */}
      <div className="bg-white border border-gray-200 rounded-2xl p-4">
        <p className="font-bold text-body text-sm mb-3">After execution</p>
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm text-body">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#16a34a" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20 6L9 17l-5-5"/>
            </svg>
            <span>Sell listed stocks: Today ✓</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-body">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#16a34a" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20 6L9 17l-5-5"/>
            </svg>
            <span>Use details for ITR-2: Auto-filled ✓</span>
          </div>
        </div>
      </div>

      {/* Warning */}
      <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4">
        <p className="text-sm text-amber-800">
          ⚠ <strong>Final review:</strong> 6 trades will execute via your Zerodha account. Total brokerage ≈ ₹120. Trades are reversible until they settle (T+1).
        </p>
      </div>

      <button
        onClick={onExecute}
        className="w-full bg-accent text-white font-bold py-4 rounded-2xl text-base active:scale-[0.98] transition"
      >
        Proceed with Sale & Filing
      </button>
    </>
  );
}

function ExecutingState({ progress }: { progress: number }) {
  return (
    <div className="space-y-4">
      <div className="text-center pt-2">
        <p className="font-bold text-body text-lg">Executing trades...</p>
        <p className="text-muted text-sm mt-1">Routing through Zerodha Kite Connect. Do not close the app.</p>
      </div>
      <div className="bg-white border border-gray-200 rounded-2xl divide-y divide-gray-100">
        {trades.map((t, i) => {
          const done = i < progress;
          const current = i === progress;
          return (
            <div key={i} className="px-4 py-3 flex items-center gap-3">
              <div className="flex-shrink-0 w-6 h-6 flex items-center justify-center">
                {done ? (
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="12" r="10" fill="#dcfce7" stroke="#16a34a" strokeWidth="1.5"/>
                    <path d="M8 12l3 3 5-5" stroke="#16a34a" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                ) : current ? (
                  <div className="w-5 h-5 rounded-full border-2 border-accent border-t-transparent animate-spin" />
                ) : (
                  <div className="w-5 h-5 rounded-full border-2 border-gray-300" />
                )}
              </div>
              <div>
                <p className={`text-sm font-semibold ${done ? "text-muted line-through" : "text-body"}`}>{t.label}</p>
                <p className="text-xs text-muted">{t.detail}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function DoneState({ navigate }: { navigate: (path: string) => void }) {
  return (
    <div className="flex flex-col items-center text-center pt-6 space-y-4">
      <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center">
        <svg width="40" height="40" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="10" stroke="#16a34a" strokeWidth="1.5"/>
          <path d="M8 12l3 3 5-5" stroke="#16a34a" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </div>
      <div>
        <p className="text-2xl font-bold text-body">All done!</p>
        <p className="text-base text-body mt-1">You just saved <span className="text-accent font-bold">₹3,500</span> in tax.</p>
        <p className="text-sm text-muted mt-1">Plus ₹8,000 banked for the next 8 years.</p>
      </div>

      <div className="bg-bgsoft border border-gray-200 rounded-2xl p-4 w-full text-left mt-2">
        <p className="font-bold text-body text-sm mb-3">Next steps</p>
        <ul className="space-y-2 text-sm text-body">
          <li className="flex items-start gap-2">
            <span className="text-accent mt-0.5">→</span>
            <span>ITR-2 Schedule CG will auto-populate in July</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-accent mt-0.5">→</span>
            <span>We'll alert you the next time gains book up</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-accent mt-0.5">→</span>
            <span>Year-End Wrapped drops on March 31</span>
          </li>
        </ul>
      </div>

      <button
        onClick={() => navigate("/wrapped")}
        className="w-full bg-accent text-white font-bold py-4 rounded-2xl text-base active:scale-[0.98] transition"
      >
        See your Year-End Wrapped →
      </button>
      <button
        onClick={() => navigate("/dashboard")}
        className="text-muted text-sm py-2 active:opacity-70 transition"
      >
        Back to dashboard
      </button>
    </div>
  );
}
