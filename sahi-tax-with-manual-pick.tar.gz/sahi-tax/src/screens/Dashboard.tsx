import { useNavigate } from "react-router-dom";
import { Header, BottomNav } from "../components/Layout";
import { arjun, holdings, taxStatus, computePnL } from "../data/arjun";
import { inr } from "../lib/format";

export default function Dashboard() {
  const navigate = useNavigate();

  const totalInvested = holdings.reduce((s, h) => s + computePnL(h).invested, 0);
  const totalCurrent = holdings.reduce((s, h) => s + computePnL(h).current, 0);
  const totalPnL = totalCurrent - totalInvested;
  const totalPnLPct = (totalPnL / totalInvested) * 100;

  return (
    <div className="min-h-screen bg-bgsoft flex flex-col">
      <Header
        title={`Hi, ${arjun.name.split(" ")[0]} 👋`}
        subtitle={`FY ${arjun.fy} · Updated ${arjun.lastUpdated}`}
        rightElement={
          <button
            onClick={() => navigate("/profile")}
            className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center text-white font-bold text-sm"
          >
            A
          </button>
        }
      />

      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 pb-24">
        {/* Tax Owed Card */}
        <div className="bg-red-50 border border-red-200 rounded-2xl p-4">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[10px] font-bold tracking-widest uppercase text-warn">You Owe (FY {arjun.fy})</p>
              <p className="text-4xl font-bold text-warn mt-1">{inr(taxStatus.taxOwed)}</p>
            </div>
            <div className="text-right text-sm space-y-0.5">
              <div className="text-body font-medium">STCG: {inr(taxStatus.realizedSTCG)}</div>
              <div className="text-body font-medium">LTCG: {inr(taxStatus.realizedLTCG)}</div>
              <div className="text-muted text-[11px] italic">(under exemption)</div>
            </div>
          </div>

          <p className="text-[11px] text-muted mt-3 mb-2">Choose how you want to save:</p>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => navigate("/harvest?mode=ai")}
              className="bg-accent text-white font-bold py-3 px-2 rounded-xl text-xs active:scale-[0.98] transition flex flex-col items-center gap-0.5"
            >
              <span>✨ AI Suggests</span>
              <span className="text-[10px] font-normal text-accent-soft">Save {inr(taxStatus.potentialSavings)} · 1 tap</span>
            </button>
            <button
              onClick={() => navigate("/harvest?mode=manual")}
              className="bg-white border-2 border-ink text-ink font-bold py-3 px-2 rounded-xl text-xs active:scale-[0.98] transition flex flex-col items-center gap-0.5"
            >
              <span>🎯 Pick Myself</span>
              <span className="text-[10px] font-normal text-muted">Choose stocks to sell</span>
            </button>
          </div>
        </div>

        {/* Portfolio Summary */}
        <div className="bg-white border border-gray-200 rounded-2xl p-4">
          <p className="text-[10px] font-bold tracking-widest uppercase text-muted mb-3">Portfolio Summary</p>
          <div className="flex items-end justify-between">
            <div>
              <p className="text-3xl font-bold text-body">{inr(totalCurrent)}</p>
              <p className={`text-sm font-semibold mt-1 ${totalPnL >= 0 ? "text-green-600" : "text-warn"}`}>
                {inr(totalPnL, { showSign: true })} ({totalPnLPct >= 0 ? "+" : ""}{totalPnLPct.toFixed(1)}%)
              </p>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2 mt-4 border-t border-gray-100 pt-3">
            <div className="text-center">
              <p className="text-xs text-muted">Invested</p>
              <p className="font-bold text-sm text-body mt-0.5">{inr(totalInvested, { compact: true })}</p>
            </div>
            <div className="text-center border-x border-gray-100">
              <p className="text-xs text-muted">Brokers</p>
              <p className="font-bold text-sm text-body mt-0.5">{arjun.brokers.length}</p>
            </div>
            <div className="text-center">
              <p className="text-xs text-muted">Holdings</p>
              <p className="font-bold text-sm text-body mt-0.5">{holdings.length}</p>
            </div>
          </div>
        </div>

        {/* Holdings List */}
        <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-100">
            <p className="font-bold text-body">Your Holdings ({holdings.length})</p>
          </div>
          <div className="divide-y divide-gray-50">
            {holdings.map((h) => {
              const { current, pnl, pnlPct } = computePnL(h);
              const isLoss = pnl < 0;
              const RowTag = isLoss ? "button" : "div";
              const rowProps = isLoss
                ? { onClick: () => navigate(`/harvest?mode=manual&pick=${h.symbol}`) }
                : {};
              return (
                <RowTag
                  key={h.symbol}
                  {...rowProps}
                  className={`px-4 py-3 flex justify-between items-center w-full text-left ${
                    isLoss ? "active:bg-red-50 transition" : ""
                  }`}
                >
                  <div className="flex-1 min-w-0 mr-3">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-body">{h.symbol}</span>
                      {isLoss && (
                        <span className="bg-red-100 text-warn text-[9px] font-bold tracking-widest uppercase px-1.5 py-0.5 rounded">
                          HARVEST
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-muted mt-0.5 truncate">
                      {h.name} · {h.qty} · {h.holdingPeriod === "short" ? "ST" : "LT"} · {h.sector}
                    </p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="font-bold text-sm text-body">{inr(current)}</p>
                    <p className={`text-[11px] font-semibold ${isLoss ? "text-warn" : "text-green-600"}`}>
                      {inr(pnl, { showSign: true })} ({pnlPct >= 0 ? "+" : ""}{pnlPct.toFixed(1)}%)
                    </p>
                    {isLoss && (
                      <p className="text-[9px] text-accent font-bold mt-0.5">tap to harvest →</p>
                    )}
                  </div>
                </RowTag>
              );
            })}
          </div>
        </div>

        {/* Harvest Opportunity */}
        <div className="bg-accent rounded-2xl p-4 text-white">
          <p className="text-[10px] font-bold tracking-widest uppercase text-accent-soft mb-2">Harvest Opportunity</p>
          <p className="text-base font-semibold leading-snug">
            {inr(taxStatus.potentialHarvest)} in losses sitting in Vodafone, PNB, and Paytm.
          </p>
          <p className="text-sm text-accent-soft mt-1">
            Worth {inr(taxStatus.potentialSavings)} in tax savings — if anyone helped you use them.
          </p>
          <div className="grid grid-cols-2 gap-2 mt-4">
            <button
              onClick={() => navigate("/harvest?mode=ai")}
              className="bg-white text-accent font-bold py-3 rounded-xl text-sm active:scale-[0.98] transition"
            >
              See AI plan →
            </button>
            <button
              onClick={() => navigate("/harvest?mode=manual")}
              className="bg-accent-dark text-white font-bold py-3 rounded-xl text-sm active:scale-[0.98] transition border border-white/20"
            >
              I'll pick myself
            </button>
          </div>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
