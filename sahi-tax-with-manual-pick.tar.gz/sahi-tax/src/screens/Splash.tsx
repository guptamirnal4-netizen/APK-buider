import { useNavigate } from "react-router-dom";

export default function Splash() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-accent to-accent-dark flex flex-col text-white px-6 py-10">
      {/* Brand mark + wordmark */}
      <div className="flex items-center gap-3 mt-4">
        <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
            <path d="M20 6L9 17l-5-5" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M17 3l4 4-1.5 1.5" stroke="#CCFBF1" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
        <div>
          <span className="text-4xl font-bold tracking-tight">Sahi Tax</span>
        </div>
      </div>

      {/* Headlines */}
      <div className="mt-8 flex-1">
        <p className="text-xl font-semibold leading-snug text-white/95">
          India's first AI Tax Optimizer<br />for retail investors.
        </p>
        <p className="mt-3 text-base italic text-accent-soft">
          "We pay you in saved rupees."
        </p>

        {/* Stats strip */}
        <div className="mt-8 bg-white/10 backdrop-blur-sm rounded-2xl p-4">
          <div className="grid grid-cols-3 divide-x divide-white/20">
            <div className="text-center pr-3">
              <div className="text-lg font-bold">₹8K+</div>
              <div className="text-[10px] text-white/70 mt-0.5 leading-tight">avg saved<br/>per year</div>
            </div>
            <div className="text-center px-3">
              <div className="text-lg font-bold">3 min</div>
              <div className="text-[10px] text-white/70 mt-0.5 leading-tight">to set<br/>up</div>
            </div>
            <div className="text-center pl-3">
              <div className="text-lg font-bold">8 yr</div>
              <div className="text-[10px] text-white/70 mt-0.5 leading-tight">carry-forward<br/>benefit</div>
            </div>
          </div>
        </div>

        {/* Illustration / empty space */}
        <div className="mt-10 flex justify-center">
          <div className="w-40 h-40 rounded-full bg-white/5 flex items-center justify-center">
            <div className="w-28 h-28 rounded-full bg-white/10 flex items-center justify-center">
              <svg width="56" height="56" viewBox="0 0 48 48" fill="none">
                {/* Rupee coin */}
                <circle cx="24" cy="24" r="20" fill="rgba(255,255,255,0.15)" />
                <text x="24" y="32" textAnchor="middle" fill="white" fontSize="24" fontWeight="bold" fontFamily="system-ui">₹</text>
              </svg>
            </div>
          </div>
        </div>
      </div>

      {/* CTAs */}
      <div className="flex flex-col gap-3 mt-6">
        <button
          onClick={() => navigate("/connect")}
          className="w-full bg-white text-accent font-bold py-4 rounded-2xl text-base shadow-lg active:scale-[0.98] transition"
        >
          Get started — connect portfolio
        </button>
        <button
          onClick={() => navigate("/dashboard")}
          className="w-full text-white/90 font-medium py-3 text-sm active:opacity-70 transition"
        >
          Try with Arjun's portfolio (demo) →
        </button>
      </div>
    </div>
  );
}
