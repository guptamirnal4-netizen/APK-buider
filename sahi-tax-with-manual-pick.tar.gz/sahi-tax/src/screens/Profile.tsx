import { useNavigate } from "react-router-dom";
import { Header, BottomNav } from "../components/Layout";
import { arjun, taxStatus } from "../data/arjun";
import { inr } from "../lib/format";

const settingsRows = [
  { icon: "🔗", label: "Connected brokers", value: "Zerodha, Groww" },
  { icon: "📄", label: "PAN", value: "ABCPS****X" },
  { icon: "📅", label: "Tax year", value: "FY 2025-26" },
  { icon: "🔔", label: "WhatsApp alerts", value: "Enabled" },
  { icon: "📋", label: "ITR-2 helper", value: "Auto-fill ready" },
];

export default function Profile() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-bgsoft flex flex-col">
      <Header title="Profile" />

      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 pb-24">
        {/* User card */}
        <div className="bg-accent rounded-2xl p-4 text-white">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center text-xl font-bold">
              A
            </div>
            <div>
              <p className="font-bold text-base">{arjun.name}</p>
              <p className="text-accent-soft text-sm">{arjun.occupation} · {arjun.city}</p>
            </div>
          </div>
          <div className="grid grid-cols-3 divide-x divide-white/20 border-t border-white/20 pt-3">
            <div className="text-center">
              <p className="text-[10px] uppercase tracking-widest text-accent-soft/70">Tier</p>
              <p className="font-bold text-sm mt-0.5">Premium</p>
            </div>
            <div className="text-center">
              <p className="text-[10px] uppercase tracking-widest text-accent-soft/70">Saved</p>
              <p className="font-bold text-sm mt-0.5">{inr(taxStatus.potentialSavings)}</p>
            </div>
            <div className="text-center">
              <p className="text-[10px] uppercase tracking-widest text-accent-soft/70">Banked</p>
              <p className="font-bold text-sm mt-0.5">{inr(taxStatus.carryForwardAvailable)}</p>
            </div>
          </div>
        </div>

        {/* Settings */}
        <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden">
          {settingsRows.map((row, i) => (
            <div key={i} className={`flex items-center justify-between px-4 py-3 ${i < settingsRows.length - 1 ? "border-b border-gray-100" : ""}`}>
              <div className="flex items-center gap-3">
                <span className="text-lg">{row.icon}</span>
                <span className="text-sm text-body font-medium">{row.label}</span>
              </div>
              <span className="text-sm text-muted">{row.value}</span>
            </div>
          ))}
        </div>

        {/* Plan card */}
        <div className="bg-white border border-gray-200 rounded-2xl p-4 relative overflow-hidden">
          <div className="absolute top-3 right-3 bg-accent-soft text-accent text-[10px] font-bold tracking-widest uppercase px-2 py-0.5 rounded-full">
            Active
          </div>
          <p className="text-[10px] font-bold tracking-widest uppercase text-muted">Your Plan</p>
          <p className="text-xl font-bold text-body mt-1">Harvester Premium</p>
          <p className="text-sm text-muted mt-0.5">₹499/year · Renews Mar 31, 2026</p>
          <div className="mt-4 bg-accent-soft rounded-xl p-3">
            <p className="text-sm italic text-accent">
              "You've saved 7× what you paid this year. We told you we'd pay you in saved rupees."
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center py-2">
          <p className="text-[11px] text-muted">Sahi Tax v0.1 · Demo prototype</p>
          <p className="text-[11px] text-muted">Built by Mirnal Gupta · BITS Pilani · Zupee Thesis 2026</p>
        </div>

        {/* Reset */}
        <button
          onClick={() => navigate("/")}
          className="w-full border-2 border-warn text-warn font-bold py-3 rounded-2xl text-sm active:scale-[0.98] transition"
        >
          Reset to Splash
        </button>
      </div>

      <BottomNav />
    </div>
  );
}
