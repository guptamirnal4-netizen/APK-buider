import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Header } from "../components/Layout";

type ConnectState = "choose" | "connecting" | "done";

const brokers = ["Zerodha", "Upstox", "ICICI", "Groww", "Angel One"];

export default function Connect() {
  const navigate = useNavigate();
  const [state, setState] = useState<ConnectState>("choose");
  const [connectingMsg, setConnectingMsg] = useState("Connecting to your broker...");

  function handleMethod(method: "api" | "upload") {
    setConnectingMsg(method === "api" ? "Connecting to your broker..." : "Parsing your CAS...");
    setState("connecting");
    setTimeout(() => {
      setState("done");
      setTimeout(() => navigate("/dashboard"), 1200);
    }, 1800);
  }

  if (state === "connecting") {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-white px-6">
        <div className="w-16 h-16 rounded-full border-4 border-accent border-t-transparent animate-spin mb-6" />
        <p className="text-body font-semibold text-center">{connectingMsg}</p>
        <p className="text-muted text-sm mt-2 text-center">Please wait a moment…</p>
      </div>
    );
  }

  if (state === "done") {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-white px-6">
        <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mb-4">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="10" stroke="#16a34a" strokeWidth="2"/>
            <path d="M8 12l3 3 5-5" stroke="#16a34a" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
        <p className="text-body font-bold text-lg">8 holdings synced</p>
        <p className="text-muted text-sm mt-1">Loading your tax dashboard…</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <Header
        title="Connect Your Portfolio"
        subtitle="Step 1 of 4"
        showBack
        progress={25}
      />

      <div className="flex-1 overflow-y-auto px-4 py-5 space-y-4">
        {/* Method A */}
        <div
          className="border-2 border-ink rounded-2xl p-4 cursor-pointer active:scale-[0.98] transition"
          onClick={() => handleMethod("api")}
        >
          <div className="flex items-center gap-2 mb-2">
            <span className="bg-accent text-white text-[10px] font-bold tracking-widest uppercase px-2 py-0.5 rounded">
              Method A
            </span>
            <span className="text-accent text-[10px] font-bold tracking-widest uppercase">
              Recommended
            </span>
          </div>
          <h3 className="font-bold text-body text-base">Broker API Connection</h3>
          <p className="text-muted text-sm mt-1">One OTP. Auto-syncs holdings. Works with all major brokers.</p>
          <div className="flex flex-wrap gap-2 mt-3">
            {brokers.map((b) => (
              <span key={b} className="bg-accent-soft text-accent text-[11px] font-semibold px-2.5 py-1 rounded-full">
                {b}
              </span>
            ))}
          </div>
        </div>

        {/* Method B */}
        <div
          className="border-2 border-gray-300 rounded-2xl p-4 cursor-pointer active:scale-[0.98] transition"
          onClick={() => handleMethod("upload")}
        >
          <div className="flex items-center gap-2 mb-2">
            <span className="bg-ink text-white text-[10px] font-bold tracking-widest uppercase px-2 py-0.5 rounded">
              Method B
            </span>
          </div>
          <h3 className="font-bold text-body text-base">Manual Upload (CAS / CSV / Excel)</h3>
          <p className="text-muted text-sm mt-1">Upload your Consolidated Account Statement (CAS) PDF. Universal — works for every demat.</p>
          <div className="mt-3 border-2 border-dashed border-gray-300 rounded-xl p-4 flex flex-col items-center gap-2">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#6B7280" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/>
              <polyline points="17 8 12 3 7 8"/>
              <line x1="12" y1="3" x2="12" y2="15"/>
            </svg>
            <span className="text-muted text-sm">Tap to upload file</span>
          </div>
        </div>

        {/* User profile card */}
        <div className="bg-bgsoft border border-gray-200 rounded-2xl p-4">
          <p className="text-[10px] font-bold tracking-widest uppercase text-muted mb-3">Your Profile</p>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-sm text-muted">Name</span>
              <span className="text-sm font-semibold text-body">Arjun Sharma</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-muted">PAN</span>
              <span className="text-sm font-semibold text-body">ABCPS****X</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-muted">Residential Status</span>
              <span className="text-sm font-semibold text-body">Resident Indian</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
