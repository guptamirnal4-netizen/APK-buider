import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Header, BottomNav } from "../components/Layout";
import { harvestPlan, taxStatus, holdings, computePnL } from "../data/arjun";
import { inr } from "../lib/format";

type Mode = "ai" | "manual";

// Holdings that are currently at a loss (harvestable)
const lossHoldings = holdings.filter(h => computePnL(h).pnl < 0);

// Tax rate for STCG: 20% (post-2024 budget)
const STCG_RATE = 0.20;

function calcSavings(selectedSymbols: string[]) {
  const totalLoss = lossHoldings
    .filter(h => selectedSymbols.includes(h.symbol))
    .reduce((s, h) => s + Math.abs(computePnL(h).pnl), 0);

  const offsettableGain = Math.min(totalLoss, taxStatus.realizedSTCG);
  const taxSaved = Math.round(offsettableGain * STCG_RATE);
  const netSTCG = Math.max(0, taxStatus.realizedSTCG - totalLoss);
  const carryForward = Math.max(0, totalLoss - taxStatus.realizedSTCG);

  return { totalLoss, taxSaved, netSTCG, carryForward };
}

// Replacement suggestions for manual picks
const replacements: Record<string, { symbol: string; name: string; rationale: string }> = {
  VODAFONE:  { symbol: "BHARTIARTL", name: "Bharti Airtel",       rationale: "Telecom sector exposure preserved." },
  PAYTM:     { symbol: "NYKAA",      name: "FSN E-Commerce",       rationale: "New-age fintech alternative." },
  PNB:       { symbol: "SBIN",       name: "State Bank of India",  rationale: "Stronger PSU banking substitute." },
};

export default function Harvest() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  // Read intent from URL: ?mode=ai | manual, ?pick=SYMBOL (preselect for manual)
  const initialMode: Mode = searchParams.get("mode") === "manual" ? "manual" : "ai";
  const initialPick = searchParams.get("pick");

  const [mode, setMode] = useState<Mode>(initialMode);
  const [selected, setSelected] = useState<string[]>(
    initialPick && lossHoldings.some(h => h.symbol === initialPick) ? [initialPick] : []
  );
  const [planGenerated, setPlanGenerated] = useState(false);

  // Sync mode + preselect when URL params change (e.g., navigating from Dashboard tap-to-harvest
  // while Harvest component is already mounted — useState lazy init won't re-run)
  useEffect(() => {
    const m = searchParams.get("mode");
    const p = searchParams.get("pick");
    if (m === "manual" || p) setMode("manual");
    else if (m === "ai") setMode("ai");
    if (p && lossHoldings.some(h => h.symbol === p)) {
      setSelected(prev => (prev.includes(p) ? prev : [...prev, p]));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams]);

  function toggleStock(symbol: string) {
    setPlanGenerated(false);
    setSelected(prev =>
      prev.includes(symbol) ? prev.filter(s => s !== symbol) : [...prev, symbol]
    );
  }

  const { totalLoss, taxSaved, netSTCG, carryForward } = calcSavings(selected);

  const sellPairs = harvestPlan.reduce<Array<{ sell: typeof harvestPlan[0]; buy: typeof harvestPlan[0] }>>((acc, item) => {
    if (item.action === "SELL") {
      const buy = harvestPlan.find(b => b.action === "BUY" && b.pairedWith === item.symbol);
      if (buy) acc.push({ sell: item, buy });
    }
    return acc;
  }, []);

  return (
    <div className="min-h-screen bg-bgsoft flex flex-col">
      <Header
        title="Tax Optimization Report"
        subtitle="Step 3 of 4"
        showBack
        progress={75}
      />

      <div className="flex-1 overflow-y-auto pb-24 space-y-4 py-4">

        {/* Mode Toggle */}
        <div className="mx-4">
          <div className="bg-gray-100 rounded-2xl p-1 flex gap-1">
            <button
              onClick={() => { setMode("ai"); setPlanGenerated(false); }}
              className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition ${
                mode === "ai"
                  ? "bg-accent text-white shadow"
                  : "text-muted"
              }`}
            >
              ✨ AI Suggested
            </button>
            <button
              onClick={() => { setMode("manual"); setPlanGenerated(false); }}
              className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition ${
                mode === "manual"
                  ? "bg-accent text-white shadow"
                  : "text-muted"
              }`}
            >
              🎯 Manual Pick
            </button>
          </div>
          <p className="text-[11px] text-muted text-center mt-2">
            {mode === "ai"
              ? "Sahi Tax picked the best combination for maximum savings"
              : "Select the stocks you want to sell — we'll calculate your savings"}
          </p>
        </div>

        {/* ─── AI MODE ─── */}
        {mode === "ai" && (
          <>
            {/* Big Save Callout */}
            <div className="bg-accent text-white mx-4 rounded-2xl overflow-hidden">
              <div className="p-4 flex justify-between items-center">
                <div>
                  <p className="text-[10px] font-bold tracking-widest uppercase text-accent-soft">You Save</p>
                  <p className="text-5xl font-bold mt-1">{inr(taxStatus.potentialSavings)}</p>
                </div>
                <div className="text-right text-sm space-y-1 text-white/80">
                  <p className="font-semibold">6 trades</p>
                  <p className="font-semibold">3 minutes</p>
                  <p className="font-semibold">0 risk added</p>
                </div>
              </div>
              <div className="border-t border-white/20 px-4 py-3">
                <p className="text-sm text-accent-soft">
                  Plus {inr(taxStatus.carryForwardAvailable)} carry-forward banked for next 8 years.
                </p>
              </div>
            </div>

            {/* Harvest Plan */}
            <div className="mx-4">
              <p className="text-[10px] font-bold tracking-widest uppercase text-muted mb-3">Your Harvest Plan</p>
              <div className="space-y-2">
                {harvestPlan.map((item, i) => (
                  <div key={i} className="bg-white border border-gray-200 rounded-2xl p-4">
                    <div className="flex items-start gap-3">
                      <span className={`text-[10px] font-bold tracking-wider uppercase px-2 py-1 rounded flex-shrink-0 ${
                        item.action === "SELL" ? "bg-red-100 text-warn" : "bg-accent-soft text-accent"
                      }`}>
                        {item.action}
                      </span>
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-body text-sm">{item.name}</p>
                        <p className="text-muted text-xs mt-0.5">{item.qty} shares @ {inr(item.price)}</p>
                        <p className="text-muted text-xs mt-1 italic">{item.rationale}</p>
                        {item.taxImpact && (
                          <p className="text-warn font-bold text-sm mt-1">
                            Books {inr(item.taxImpact, { showSign: true })} loss
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Tax Impact Breakdown */}
            <div className="bg-white border border-gray-200 rounded-2xl mx-4 overflow-hidden">
              <div className="px-4 py-3 border-b border-gray-100">
                <p className="font-bold text-body">Tax Impact Breakdown</p>
              </div>
              <div className="divide-y divide-gray-100">
                <div className="px-4 py-3 flex justify-between">
                  <span className="text-sm text-muted">Realized STCG (current FY)</span>
                  <span className="font-semibold text-sm text-body">{inr(taxStatus.realizedSTCG)}</span>
                </div>
                <div className="px-4 py-3 flex justify-between">
                  <span className="text-sm text-muted">Losses harvested</span>
                  <span className="font-bold text-sm text-warn">{inr(-taxStatus.potentialHarvest, { showSign: true })}</span>
                </div>
                <div className="px-4 py-3 flex justify-between border-t-2 border-gray-200">
                  <span className="text-sm font-semibold text-body">Net taxable STCG</span>
                  <span className="font-bold text-sm text-body">{inr(0)}</span>
                </div>
                <div className="px-4 py-3 flex justify-between bg-accent-soft">
                  <span className="text-sm font-bold text-accent">Tax saved this FY</span>
                  <span className="font-bold text-lg text-accent">{inr(taxStatus.potentialSavings)}</span>
                </div>
                <div className="px-4 py-3 flex justify-between">
                  <span className="text-sm text-muted">Loss banked (carry-forward)</span>
                  <span className="font-semibold text-sm text-body">{inr(taxStatus.carryForwardAvailable)}</span>
                </div>
              </div>
            </div>

            {/* Replacement Engine */}
            <div className="bg-bgsoft border border-gray-200 rounded-2xl mx-4 p-4">
              <div className="flex items-center gap-2 mb-3">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#0F766E" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10"/><path d="M8 12l2 2 4-4"/>
                </svg>
                <p className="font-bold text-sm text-body">Replacement Engine</p>
              </div>
              <p className="text-xs text-muted mb-3">Sector exposure maintained, wash-sale avoided</p>
              <div className="space-y-2">
                {sellPairs.map(({ sell, buy }, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm">
                    <span className="text-warn font-semibold">{sell.symbol}</span>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#6B7280" strokeWidth="2" strokeLinecap="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                    <span className="text-accent font-semibold">{buy.symbol}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Execute CTA */}
            <div className="mx-4">
              <button
                onClick={() => navigate("/confirm")}
                className="w-full bg-ink text-white font-bold py-4 rounded-2xl text-base active:scale-[0.98] transition"
              >
                Execute all 6 trades →
              </button>
              <p className="text-[11px] text-muted italic text-center mt-3 leading-relaxed">
                All trades executed via your linked broker (Zerodha). Sahi Tax never holds your funds.
                Compliant with Section 74 &amp; 94(7) of the Income Tax Act.
              </p>
            </div>
          </>
        )}

        {/* ─── MANUAL MODE ─── */}
        {mode === "manual" && (
          <>
            {/* Live savings ticker */}
            <div className={`mx-4 rounded-2xl p-4 transition-all ${selected.length > 0 ? "bg-accent text-white" : "bg-gray-100 text-muted"}`}>
              {selected.length === 0 ? (
                <p className="text-sm text-center font-medium">Select stocks below to see your savings</p>
              ) : (
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-[10px] font-bold tracking-widest uppercase text-accent-soft">You'll Save</p>
                    <p className="text-4xl font-bold mt-0.5">{inr(taxSaved)}</p>
                    <p className="text-xs text-accent-soft mt-0.5">{selected.length} stock{selected.length > 1 ? "s" : ""} selected · {inr(totalLoss)} loss booked</p>
                  </div>
                  <div className="text-right text-sm space-y-1 text-white/80">
                    <p>Net STCG</p>
                    <p className="font-bold text-base text-white">{inr(netSTCG)}</p>
                    {carryForward > 0 && (
                      <>
                        <p className="text-[10px] text-accent-soft">Carry-fwd</p>
                        <p className="font-bold text-sm">{inr(carryForward)}</p>
                      </>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Context */}
            <div className="mx-4 bg-white border border-gray-200 rounded-2xl p-4">
              <p className="text-[10px] font-bold tracking-widest uppercase text-muted mb-2">Your Tax Context</p>
              <div className="flex justify-between text-sm">
                <span className="text-muted">Realized STCG this FY</span>
                <span className="font-bold text-body">{inr(taxStatus.realizedSTCG)}</span>
              </div>
              <div className="flex justify-between text-sm mt-1">
                <span className="text-muted">Tax owed (20% STCG)</span>
                <span className="font-bold text-warn">{inr(taxStatus.taxOwed)}</span>
              </div>
              <p className="text-[11px] text-muted mt-2 italic">Each rupee of loss you book offsets your STCG at 20%.</p>
            </div>

            {/* Stock selector */}
            <div className="mx-4">
              <div className="flex items-center justify-between mb-3">
                <p className="text-[10px] font-bold tracking-widest uppercase text-muted">
                  Stocks at a Loss — tap to select
                </p>
                <div className="flex gap-1">
                  <button
                    onClick={() => { setSelected(lossHoldings.map(h => h.symbol)); setPlanGenerated(false); }}
                    className="text-[10px] font-bold text-accent uppercase tracking-wider px-2 py-1 hover:bg-accent-soft rounded transition"
                  >
                    Select all
                  </button>
                  {selected.length > 0 && (
                    <button
                      onClick={() => { setSelected([]); setPlanGenerated(false); }}
                      className="text-[10px] font-bold text-muted uppercase tracking-wider px-2 py-1 hover:bg-gray-100 rounded transition"
                    >
                      Clear
                    </button>
                  )}
                </div>
              </div>
              <div className="space-y-2">
                {lossHoldings.map(h => {
                  const { current, pnl, pnlPct } = computePnL(h);
                  const isSelected = selected.includes(h.symbol);
                  const loss = Math.abs(pnl);
                  const thisSaving = Math.round(Math.min(loss, taxStatus.realizedSTCG) * STCG_RATE);

                  return (
                    <button
                      key={h.symbol}
                      onClick={() => toggleStock(h.symbol)}
                      className={`w-full text-left rounded-2xl border-2 p-4 transition active:scale-[0.98] ${
                        isSelected
                          ? "border-accent bg-accent-soft"
                          : "border-gray-200 bg-white"
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        {/* Left */}
                        <div className="flex items-start gap-3">
                          <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 mt-0.5 ${
                            isSelected ? "border-accent bg-accent" : "border-gray-400"
                          }`}>
                            {isSelected && (
                              <svg width="11" height="11" viewBox="0 0 12 12" fill="none">
                                <path d="M2 6l3 3 5-5" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                              </svg>
                            )}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-sm text-body">{h.symbol}</span>
                              <span className="text-[9px] bg-red-100 text-warn font-bold tracking-widest uppercase px-1.5 py-0.5 rounded">LOSS</span>
                            </div>
                            <p className="text-[11px] text-muted mt-0.5">{h.name}</p>
                            <p className="text-[11px] text-muted">{h.qty} shares · {h.holdingPeriod === "short" ? "Short-term" : "Long-term"}</p>
                          </div>
                        </div>
                        {/* Right */}
                        <div className="text-right flex-shrink-0">
                          <p className="font-bold text-sm text-body">{inr(current)}</p>
                          <p className="text-warn font-bold text-sm">{inr(pnl, { showSign: true })}</p>
                          <p className="text-[10px] text-warn">({pnlPct.toFixed(1)}%)</p>
                          {isSelected && (
                            <p className="text-[10px] text-accent font-bold mt-1">
                              saves ~{inr(thisSaving)}
                            </p>
                          )}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* No losses note */}
            {lossHoldings.length === 0 && (
              <div className="mx-4 bg-green-50 border border-green-200 rounded-2xl p-4 text-center">
                <p className="text-green-700 font-semibold text-sm">🎉 No stocks at a loss right now!</p>
                <p className="text-green-600 text-xs mt-1">Your portfolio is fully in the green. Nothing to harvest.</p>
              </div>
            )}

            {/* Generate Plan CTA */}
            {selected.length > 0 && !planGenerated && (
              <div className="mx-4">
                <button
                  onClick={() => setPlanGenerated(true)}
                  className="w-full bg-accent text-white font-bold py-4 rounded-2xl text-base active:scale-[0.98] transition"
                >
                  Generate My Harvest Plan →
                </button>
              </div>
            )}

            {/* Generated Manual Plan */}
            {planGenerated && selected.length > 0 && (
              <>
                <div className="mx-4">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="flex-1 h-px bg-gray-200" />
                    <p className="text-[10px] font-bold tracking-widest uppercase text-muted">Your Custom Plan</p>
                    <div className="flex-1 h-px bg-gray-200" />
                  </div>
                  <div className="space-y-2">
                    {selected.map(sym => {
                      const h = lossHoldings.find(h => h.symbol === sym)!;
                      const { pnl } = computePnL(h);
                      const rep = replacements[sym];
                      return (
                        <div key={sym}>
                          {/* SELL row */}
                          <div className="bg-white border border-gray-200 rounded-2xl p-4 mb-1">
                            <div className="flex items-start gap-3">
                              <span className="text-[10px] font-bold tracking-wider uppercase px-2 py-1 rounded flex-shrink-0 bg-red-100 text-warn">SELL</span>
                              <div>
                                <p className="font-semibold text-body text-sm">{h.name}</p>
                                <p className="text-muted text-xs">{h.qty} shares @ {inr(h.currentPrice)}</p>
                                <p className="text-warn font-bold text-sm mt-1">Books {inr(pnl, { showSign: true })} loss</p>
                              </div>
                            </div>
                          </div>
                          {/* BUY replacement row */}
                          {rep && (
                            <div className="bg-white border border-gray-200 rounded-2xl p-4">
                              <div className="flex items-start gap-3">
                                <span className="text-[10px] font-bold tracking-wider uppercase px-2 py-1 rounded flex-shrink-0 bg-accent-soft text-accent">BUY</span>
                                <div>
                                  <p className="font-semibold text-body text-sm">{rep.name} ({rep.symbol})</p>
                                  <p className="text-muted text-xs italic mt-0.5">{rep.rationale}</p>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Manual Tax Breakdown */}
                <div className="bg-white border border-gray-200 rounded-2xl mx-4 overflow-hidden">
                  <div className="px-4 py-3 border-b border-gray-100">
                    <p className="font-bold text-body">Your Tax Impact</p>
                  </div>
                  <div className="divide-y divide-gray-100">
                    <div className="px-4 py-3 flex justify-between">
                      <span className="text-sm text-muted">Realized STCG</span>
                      <span className="font-semibold text-sm text-body">{inr(taxStatus.realizedSTCG)}</span>
                    </div>
                    <div className="px-4 py-3 flex justify-between">
                      <span className="text-sm text-muted">Losses you're booking</span>
                      <span className="font-bold text-sm text-warn">{inr(-totalLoss, { showSign: true })}</span>
                    </div>
                    <div className="px-4 py-3 flex justify-between border-t-2 border-gray-200">
                      <span className="text-sm font-semibold text-body">Net taxable STCG</span>
                      <span className="font-bold text-sm text-body">{inr(netSTCG)}</span>
                    </div>
                    <div className="px-4 py-3 flex justify-between bg-accent-soft">
                      <span className="text-sm font-bold text-accent">Tax saved this FY</span>
                      <span className="font-bold text-lg text-accent">{inr(taxSaved)}</span>
                    </div>
                    {carryForward > 0 && (
                      <div className="px-4 py-3 flex justify-between">
                        <span className="text-sm text-muted">Carry-forward banked</span>
                        <span className="font-semibold text-sm text-body">{inr(carryForward)}</span>
                      </div>
                    )}
                  </div>
                </div>

                {taxSaved < taxStatus.potentialSavings && (
                  <div className="mx-4 bg-amber-50 border border-amber-200 rounded-2xl p-3">
                    <p className="text-sm text-amber-800">
                      💡 The AI suggestion saves <strong>{inr(taxStatus.potentialSavings)}</strong> vs your <strong>{inr(taxSaved)}</strong>. Switch to AI mode to maximize savings.
                    </p>
                  </div>
                )}

                <div className="mx-4">
                  <button
                    onClick={() => navigate("/confirm")}
                    className="w-full bg-ink text-white font-bold py-4 rounded-2xl text-base active:scale-[0.98] transition"
                  >
                    Execute {selected.length * 2} trades →
                  </button>
                  <p className="text-[11px] text-muted italic text-center mt-3 leading-relaxed">
                    All trades executed via your linked broker (Zerodha). Sahi Tax never holds your funds.
                    Compliant with Section 74 &amp; 94(7) of the Income Tax Act.
                  </p>
                </div>
              </>
            )}
          </>
        )}
      </div>

      <BottomNav />
    </div>
  );
}
