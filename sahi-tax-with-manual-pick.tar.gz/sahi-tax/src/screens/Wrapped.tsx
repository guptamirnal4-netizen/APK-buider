import { Header, BottomNav } from "../components/Layout";
import { yearEndStats } from "../data/arjun";
import { inr } from "../lib/format";

export default function Wrapped() {
  return (
    <div className="min-h-screen bg-bgsoft flex flex-col">
      <Header title="Year-End Wrapped" subtitle="FY 2025-26" />

      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 pb-24">
        {/* Hero card */}
        <div className="bg-gradient-to-br from-ink to-gray-800 text-white rounded-3xl overflow-hidden">
          <div className="h-1 bg-accent" />
          <div className="p-5">
            <p className="text-[10px] font-bold tracking-widest uppercase text-accent-soft">FY 2025-26 Wrapped</p>
            <p className="text-white/80 text-base mt-2">Arjun, you saved</p>
            <p className="text-6xl font-bold tracking-tight mt-1">{inr(yearEndStats.totalTaxSaved)}</p>
            <p className="italic text-accent-soft mt-1">in tax this year.</p>
          </div>
          <div className="border-t border-white/10 px-5 py-4">
            <p className="text-[10px] font-bold tracking-widest uppercase text-white/50">Carry-Forward Banked</p>
            <p className="text-2xl font-bold mt-1">{inr(yearEndStats.carryForwardBanked)}</p>
            <p className="text-white/60 text-xs mt-0.5">Usable through {yearEndStats.carryForwardUsableUntil}</p>
          </div>
        </div>

        {/* Stat grid */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white border border-gray-200 rounded-2xl p-4">
            <p className="text-[10px] font-bold tracking-widest uppercase text-muted">Total Harvests</p>
            <p className="text-4xl font-bold text-body mt-2">{yearEndStats.totalHarvests}</p>
            <p className="text-xs text-muted mt-1">opportunities found</p>
          </div>
          <div className="bg-white border border-gray-200 rounded-2xl p-4">
            <p className="text-[10px] font-bold tracking-widest uppercase text-muted">Losses Booked</p>
            <p className="text-4xl font-bold text-warn mt-2">{inr(yearEndStats.totalLossesBooked, { compact: true })}</p>
            <p className="text-xs text-muted mt-1">strategically harvested</p>
          </div>
        </div>

        {/* Biggest Win */}
        <div className="bg-accent rounded-2xl p-4 text-white">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-2xl">🏆</span>
            <p className="text-[10px] font-bold tracking-widest uppercase text-accent-soft">Biggest Win</p>
          </div>
          <p className="font-bold text-base">{yearEndStats.topHarvest.stock}</p>
          <p className="text-accent-soft text-sm">Saved {inr(yearEndStats.topHarvest.saved)} in one harvest</p>
        </div>

        {/* Rank card */}
        <div className="bg-white border border-gray-200 rounded-2xl p-4">
          <p className="text-[10px] font-bold tracking-widest uppercase text-muted mb-2">Your Sahi Tax Rank</p>
          <p className="font-bold text-body">{yearEndStats.rank}</p>
          <div className="mt-3 bg-gray-100 rounded-full h-3 overflow-hidden">
            <div className="bg-accent h-full rounded-full" style={{ width: "92%" }} />
          </div>
          <p className="text-xs text-muted mt-1">Top 8%</p>
        </div>

        {/* Compounding callout */}
        <div className="border-2 border-dashed border-gray-300 rounded-2xl p-4">
          <p className="font-bold text-body text-sm mb-2">What this saving means in 8 years</p>
          <p className="text-sm text-muted leading-relaxed">
            If you keep harvesting losses every year (avg ₹3,500/yr) and reinvest at 12%, you'll have built an extra <strong className="text-body">₹43,000</strong> by FY 2033-34 — without changing your investment style.
          </p>
        </div>

        {/* Share CTA */}
        <button className="w-full flex items-center justify-center gap-3 py-4 rounded-2xl font-bold text-white text-base active:scale-[0.98] transition" style={{ backgroundColor: "#25D366" }}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="white">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
            <path d="M11.999 2C6.477 2 2 6.477 2 12c0 1.89.525 3.66 1.438 5.168L2 22l4.978-1.304A9.956 9.956 0 0012 22c5.523 0 10-4.477 10-10S17.522 2 11.999 2z"/>
          </svg>
          Share on WhatsApp
        </button>

        {/* PDF download */}
        <button className="w-full text-accent font-semibold text-sm py-2 active:opacity-70 transition">
          Download ITR Schedule CG (PDF)
        </button>
      </div>

      <BottomNav />
    </div>
  );
}
