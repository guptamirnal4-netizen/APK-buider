export function inr(n: number, opts: { showSign?: boolean; compact?: boolean } = {}): string {
  const { showSign = false, compact = false } = opts;
  const sign = n < 0 ? "−" : showSign && n > 0 ? "+" : "";
  const abs = Math.abs(n);
  if (compact) {
    if (abs >= 10000000) return `${sign}₹${(abs / 10000000).toFixed(2)}Cr`;
    if (abs >= 100000) return `${sign}₹${(abs / 100000).toFixed(2)}L`;
    if (abs >= 1000) return `${sign}₹${(abs / 1000).toFixed(1)}K`;
    return `${sign}₹${abs.toFixed(0)}`;
  }
  // Indian comma format: 12,34,567 (group 3, then group 2)
  const numStr = abs.toFixed(0);
  let formatted: string;
  if (numStr.length <= 3) {
    formatted = numStr;
  } else {
    const last3 = numStr.slice(-3);
    const rest = numStr.slice(0, -3);
    const restWithCommas = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ",");
    formatted = restWithCommas + "," + last3;
  }
  return `${sign}₹${formatted}`;
}
