import { HashRouter, Routes, Route } from "react-router-dom";
import Splash from "./screens/Splash";
import Connect from "./screens/Connect";
import Dashboard from "./screens/Dashboard";
import Harvest from "./screens/Harvest";
import Confirm from "./screens/Confirm";
import Wrapped from "./screens/Wrapped";
import Profile from "./screens/Profile";

export default function App() {
  return (
    <HashRouter>
      <div className="app-shell">
        <Routes>
          <Route path="/" element={<Splash />} />
          <Route path="/connect" element={<Connect />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/harvest" element={<Harvest />} />
          <Route path="/confirm" element={<Confirm />} />
          <Route path="/wrapped" element={<Wrapped />} />
          <Route path="/profile" element={<Profile />} />
        </Routes>
      </div>
    </HashRouter>
  );
}
