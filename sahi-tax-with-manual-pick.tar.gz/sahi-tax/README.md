# Sahi Tax — India's first AI Tax Optimizer for retail investors

> Thesis prototype · Mirnal Gupta · BITS Pilani · Zupee Thesis 2026

## Quick Start

```bash
npm install
npm run dev
# Open http://localhost:5173
```

## APK Build Steps

Prerequisites: JDK 17, Android Studio (SDK 34), Node 18+

```bash
npm install
npm run build
npx cap add android       # first time only
npx cap sync android
npx cap open android      # then Build → Build APK(s) in Android Studio
```

Or: `chmod +x build-apk.sh && ./build-apk.sh`

## Honest Scope Cuts (deliberate for thesis)

| Feature | Status |
|---|---|
| Real CAS PDF parsing | Simulated (1.8s delay → hardcoded data) |
| Real broker API / OTP | Simulated |
| Live market prices | Static (hardcoded in src/data/arjun.ts) |
| Real trade execution | Animated simulation only |
| AI chat / "Ask Sahi Tax" | Phase 2 — not built |
| ITR-2 auto-fill | UI placeholder only |
| WhatsApp share | Button present, no real share |

## File Structure

```
src/
  components/Layout.tsx   Header, BottomNav, ProgressBar
  data/arjun.ts           All demo data + types
  lib/format.ts           Indian rupee formatter
  screens/                7 screens (Splash→Connect→Dashboard→Harvest→Confirm→Wrapped→Profile)
  App.tsx                 HashRouter + routes
public/
  icon-192.png / icon-512.png   PWA icons
  manifest.webmanifest          PWA manifest
capacitor.config.ts
build-apk.sh
```
